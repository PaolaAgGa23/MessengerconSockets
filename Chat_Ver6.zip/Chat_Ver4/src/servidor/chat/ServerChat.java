package servidor.chat;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ServerChat extends JFrame {

    private static final int PORT = 1234;
    private static final String USER_FILE_PATH = System.getProperty("user.dir");;
    private List<String> listaClientes = new ArrayList<>();
    private List<String> listaMensajes = new ArrayList<>();

    private Map<String, String> users;
    
    private JTextArea logTextArea;
    private JButton startButton;
    private JButton stopButton;


    public ServerChat() {
        String filePath = USER_FILE_PATH + "/usuarios.txt";
        File file = new File(filePath);

        if (file.exists()) {
            log("El archivo usuarios.txt ya existe.");
        } else {
            try {
                boolean created = file.createNewFile();
                if (created) {
                    log("El archivo usuarios.txt ha sido creado.");
                } else {
                    log("No se pudo crear el archivo usuarios.txt.");
                }
            } catch (IOException e) {
                log("Ocurrió un error al crear el archivo usuarios.txt: " + e.getMessage());
            }
        }
        
        File directory = new File(USER_FILE_PATH + "/archivos");
        
        if (directory.exists()) {
            log("El directorio archivos ya existe.");
        } else {
            boolean created = directory.mkdirs();
            if (created) {
                log("El directorio archivos ha sido creado.");
            } else {
                log("No se pudo crear el directorio archivos.");
            }
        }
        
        users = readUserFile();
        initializeGUI();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ServerChat();
            }
        });
    }
    
    private void initializeGUI() {
        setTitle("Servidor");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        logTextArea = new JTextArea();
        logTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logTextArea);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        startButton = new JButton("Encender servidor");
        stopButton = new JButton("Apagar servidor");
        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);
        add(buttonPanel, BorderLayout.SOUTH);

        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startServer();
                startButton.setEnabled(false);
                stopButton.setEnabled(true);
                log("Servidor encendido. Esperando conexiones por el puerto: " + PORT);
            }
        });

        stopButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                stopServer();
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
                log("Servidor apagado.");
            }
        });
        stopButton.setEnabled(false);

        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void startServer() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    InetAddress ipAddress = InetAddress.getLocalHost();
                    String serverIP = ipAddress.getHostAddress();
                    log("Dirección IP del servidor: " + serverIP);

                    ServerSocket serverSocket = new ServerSocket(PORT, 0, InetAddress.getByName("0.0.0.0"));
                    while (true) {
                        Socket socket = serverSocket.accept();
                        log("Cliente conectado: " + socket.getInetAddress().getHostAddress());

                        Thread clientThread = new Thread(new ClientHandler(socket));
                        clientThread.start();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
    
    private void stopServer() {
        System.exit(0);
    }

    private class ClientHandler implements Runnable {

        private Socket clientSocket;
        private BufferedReader reader;
        private PrintWriter writer;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;

            try {
                reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                writer = new PrintWriter(clientSocket.getOutputStream(), true);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void run() {
            try {
                String action = reader.readLine();
                if (action.equals("iniciarSesion")) {
                    String username = reader.readLine();
                    String password = reader.readLine();
                    log("Intento de inicio de sesión: " + username);

                    String r = checkCredentials(username, password);
                    writer.println(r);
                    if (r.equals("usuarioAutenticado")) {
                        listaClientes.add(username);
                        log("inicio de sesión: " + username + " exitoso.");
                    }
                } else if (action.equals("usuarioRegistrar")) {
                    String username = reader.readLine();
                    String password = reader.readLine();
                    if (registerUser(username, password)) {
                        writer.println("usuarioRegistrado");
                        log("Usuario registrado");
                    } else {
                        log("Usuario no registrado");
                    }
                } else if (action.equals("listaClientes")) {
                    if (listaClientes.size() > 0) {
                        writer.println("listadoClientes");
                        log("Listado de usuarios");
                        for (String cliente : listaClientes) {
                            writer.println(cliente);
                        }
                    } else {
                        writer.println("listadoClientesVacio");
                    }
                } else if (action.equals("enviarMensaje")) {
                    String mensaje = reader.readLine();
                    listaMensajes.add(mensaje);
                    writer.println("mensajeRecibido");
                    log("Mensaje recibido " + mensaje);
                } else if (action.equals("listaMensajes")) {
                    if (listaMensajes.size() > 0) {
                        writer.println("listadoMensajes");
                        log("Listado de Mensajes");
                        for ( String m : listaMensajes) {
                            System.out.println(m);
                            writer.println(m);
                        }
                    } else {
                        writer.println("listadoMensajesVacio");
                    }
                } else if (action.equals("desconectarUsuario")) {
                    String username = reader.readLine();
                    listaClientes.remove(username);
                    writer.println("desconectado");
                    log("Desconectar usuario: " + username);
                    if (listaClientes.size() == 0) {
                        listaMensajes.clear();
                    }
                } else if (action.equals("enviarArchivo")) {
                    
                    String username = reader.readLine();
                    String nombreArchivo = reader.readLine();
                    
                    DataInputStream dis = null;
                    FileOutputStream fos = null;
                    
                    dis = new DataInputStream(this.clientSocket.getInputStream());
                    
                    // String fileName = dis.readUTF();
                    File directory = new File(USER_FILE_PATH + "/archivos/" + username);
                    if (directory.exists()) {
                        log("El directorio archivos ya existe.");
                    } else {
                        boolean created = directory.mkdirs();
                        if (created) {
                            log("El directorio archivos ha sido creado.");
                        } else {
                            log("No se pudo crear el directorio archivos.");
                        }
                    }
        
                    File file = new File(USER_FILE_PATH + "/archivos/" + username + "/" + nombreArchivo);

                    fos = new FileOutputStream(file);
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = dis.read(buffer)) != -1) {
                        fos.write(buffer, 0, bytesRead);
                    }
                    dis.close();
                    fos.close();
                    log("Enviar archivo: " + nombreArchivo + " al usuario " + username);
                } else if (action.equals("listaArchivos")) {
                    String username = reader.readLine();
                    
                    System.out.println("Entre en el listado");
                    File directory = new File(USER_FILE_PATH + "/archivos/" + username);
                    if (directory.exists() && directory.isDirectory()) {
                        File[] files = directory.listFiles();
                        if (files != null && files.length > 0) {
                            writer.println("listadoArchivos");
                            for (File file : files) {
                                writer.println(file.getName());
                                System.out.println(file.getName());
                            }
                        } else {
                            writer.println("listadoArchivosVacio");
                        }
                    } else {
                        writer.println("errorDirectorio");
                    }
                } else if (action.equals("descargarArchivo")) {
                    
                    String username = reader.readLine();
                    String nombreArchivo = reader.readLine();
                    System.out.println(username + " " + nombreArchivo);
                    
                    File file = new File(USER_FILE_PATH + "/archivos/" + username + "/" + nombreArchivo);
                    FileInputStream fis = new FileInputStream(file);
                    
                    OutputStream ops = clientSocket.getOutputStream();

                    DataOutputStream dos = new DataOutputStream(ops);
                    dos.writeUTF(file.getName());

                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        ops.write(buffer, 0, bytesRead);
                    }
                    
                    fis.close();
                    ops.close();
                    dos.close();
                    log("Descargando  archivo: " + nombreArchivo + " el usuario " + username);
                }
                reader.close();
                writer.close();
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private String checkCredentials(String username, String password) {
            String respuesta = "";
            if (users.containsKey(username)) {
                String storedPassword = users.get(username);
                if (password.equals(storedPassword)) {
                    respuesta = "usuarioAutenticado";
                    boolean contieneUsuario = listaClientes.contains(username);
                    if(contieneUsuario){
                        respuesta = "usuarioEnChat";
                    }
                } else {
                    respuesta = "usuarioContraseniaIncorrecta";
                }
            } else {
                respuesta = "usuarioNoExiste";
            }
            return respuesta;
        }
    }

    private boolean registerUser(String username, String password) {
        if (!users.containsKey(username)) {
            users.put(username, password);
            saveUserFile();
            return true;
        }
        return false;
    }

    private Map<String, String> readUserFile() {
        Map<String, String> userMap = new HashMap<>();
        try {
            BufferedReader fileReader = new BufferedReader(new FileReader(USER_FILE_PATH + "\\usuarios.txt"));
            String line;
            while ((line = fileReader.readLine()) != null) {
                String[] parts = line.split(",");
                String storedUsername = parts[0].trim();
                String storedPassword = parts[1].trim();
                userMap.put(storedUsername, storedPassword);
            }
            fileReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return userMap;
    }

    private void saveUserFile() {
        try {
            PrintWriter fileWriter = new PrintWriter(new FileWriter(USER_FILE_PATH + "\\usuarios.txt"));
            for (Map.Entry<String, String> entry : users.entrySet()) {
                fileWriter.println(entry.getKey() + "," + entry.getValue());
            }
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void log(String message) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                logTextArea.append(message + "\n");
            }
        });
    }
}