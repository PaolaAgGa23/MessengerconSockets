package servidor.chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PeerThread extends Thread {
    private BufferedReader bufferedReader;

    public PeerThread(Socket socket) throws IOException {
        bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    public void run() {
        boolean flag = true;
        while (flag) {
            try {
                String jsonString = bufferedReader.readLine();
                Map<String, Object> jsonObject = parseJsonObject(jsonString);
                if (jsonObject.containsKey("username"))
                    System.out.println("[" + jsonObject.get("username") + "]: " + jsonObject.get("message"));
            } catch (Exception e) {
                flag = false;
                interrupt();
            }
        }
    }

    private Map<String, Object> parseJsonObject(String jsonString) {
        Map<String, Object> jsonObject = new HashMap<>();
        jsonString = jsonString.trim();
        if (jsonString.startsWith("{") && jsonString.endsWith("}")) {
            jsonString = jsonString.substring(1, jsonString.length() - 1);
            String[] entries = jsonString.split(",");
            for (String entry : entries) {
                String[] parts = entry.split(":", 2);
                if (parts.length == 2) {
                    String key = parts[0].trim().replaceAll("^\"|\"$", "");
                    String value = parts[1].trim();
                    jsonObject.put(key, parseJsonValue(value));
                }
            }
        }
        return jsonObject;
    }

    private Object parseJsonValue(String jsonValue) {
        jsonValue = jsonValue.trim();
        if (jsonValue.startsWith("\"") && jsonValue.endsWith("\"")) {
            return jsonValue.substring(1, jsonValue.length() - 1);
        } else if ("null".equals(jsonValue)) {
            return null;
        } else if ("true".equals(jsonValue)) {
            return true;
        } else if ("false".equals(jsonValue)) {
            return false;
        } else if (jsonValue.startsWith("[") && jsonValue.endsWith("]")) {
            List<Object> list = new ArrayList<>();
            jsonValue = jsonValue.substring(1, jsonValue.length() - 1);
            String[] items = jsonValue.split(",");
            for (String item : items) {
                list.add(parseJsonValue(item));
            }
            return list;
        } else {
            try {
                return Integer.parseInt(jsonValue);
            } catch (NumberFormatException e) {
                // Ignore and try parsing as a double
            }
            try {
                return Double.parseDouble(jsonValue);
            } catch (NumberFormatException e) {
                // Ignore and treat as a string
                return jsonValue;
            }
        }
    }
}