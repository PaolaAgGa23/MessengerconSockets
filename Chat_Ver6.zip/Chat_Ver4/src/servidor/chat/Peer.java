package servidor.chat;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.io.File;

public class Peer {
    private ClientChat clientChat;

    public void setClientChat(ClientChat clientChat) {
    this.clientChat = clientChat;
    }
    public void chat (String[] args) throws Exception { 
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Ingrese su nombre de usuario y el num de puerto : ");
        String[] setupValues = bufferedReader.readLine().split(" ");
        ServerThread serverThread = new ServerThread(setupValues[1]);
        serverThread.start();
        //new Peer().updateListenToPeers(bufferedReader, setupValues[0], serverThread);
        new Peer().updateListenToPeers(bufferedReader, setupValues[0], serverThread, clientChat);
    }

        public void updateListenToPeers(BufferedReader bufferedReader, String username, ServerThread serverThread, ClientChat clientChat) throws Exception  {
        System.out.println("Ingresa el host con el que deseas establecer conexión (localhost:port#) ");
        System.out.println("Si solo quieres recibir mensajes presiona s");
        String input = bufferedReader.readLine();
        String[] inputValues = input.split(" ");
        if (!input.equals("s")) {
            for (int i = 0; i < inputValues.length; i++) {
                String[] address = inputValues[i].split(":");
                Socket socket = null;
                try {
                    socket = new Socket(address[0], Integer.valueOf(address[1]));
                    new PeerThread(socket).start();
                } catch (Exception e) {
                    if (socket != null)
                        socket.close();
                    else
                        System.out.println("Entada invalida. Pasando al siguiente paso");
                }
            }//localhost:4442
        }
         communicate(bufferedReader, username, serverThread, clientChat);
    }

    public void communicate(BufferedReader bufferedReader, String username, ServerThread serverThread, ClientChat clientChat) {
        try {
            System.out.println("Ahora puedes comunicarte. Presiona e para salir ó c para cambiar el host");
            boolean flag = true;
            while (flag) {
                String message = bufferedReader.readLine();
                if(message.equals("e")) {
                    flag = false;
                    clientChat.showChatWindow(); // Llama al método en la instancia de ClientChat
                    break;
                } else if (message.equals("c")) {
                    updateListenToPeers(bufferedReader, username, serverThread,clientChat);
                } else {
                    Map<String, Object> jsonObject = new HashMap<>();
                    jsonObject.put("username", username);
                    jsonObject.put("message", message);
                    StringWriter stringWriter = new StringWriter();
                    writeJsonObject(stringWriter, jsonObject);
                    serverThread.sendMessage(stringWriter.toString());
                }
            }
            System.exit(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void writeJsonObject(StringWriter stringWriter, Map<String, Object> jsonObject) {
        stringWriter.append("{");
        boolean firstEntry = true;
        for (Map.Entry<String, Object> entry : jsonObject.entrySet()) {
            if (!firstEntry) {
                stringWriter.append(",");
            }
            firstEntry = false;
            stringWriter.append("\"").append(entry.getKey()).append("\":");
            writeJsonValue(stringWriter, entry.getValue());
        }
        stringWriter.append("}");
    }

    private void writeJsonValue(StringWriter stringWriter, Object value) {
        if (value == null) {
            stringWriter.append("null");
        } else if (value instanceof String) {
            stringWriter.append("\"").append(value.toString()).append("\"");
        } else if (value instanceof Number || value instanceof Boolean) {
            stringWriter.append(value.toString());
        } else if (value instanceof Map) {
            writeJsonObject(stringWriter, (Map<String, Object>) value);
        } else if (value instanceof Iterable) {
            stringWriter.append("[");
            boolean firstItem = true;
            for (Object item : (Iterable<?>) value) {
                if (!firstItem) {
                    stringWriter.append(",");
                }
                firstItem = false;
                writeJsonValue(stringWriter, item);
            }
            stringWriter.append("]");
        } else {
            throw new IllegalArgumentException("Tipo de valor no compatible: " + value.getClass());
        }
    }
}